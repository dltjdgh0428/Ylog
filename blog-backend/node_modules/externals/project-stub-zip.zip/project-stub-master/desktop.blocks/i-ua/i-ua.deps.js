 ({
    mustDeps: [{ block: 'bemhtml' }],
    noDeps: [{ block: 'i-bem', elems: 'html' }]
})
